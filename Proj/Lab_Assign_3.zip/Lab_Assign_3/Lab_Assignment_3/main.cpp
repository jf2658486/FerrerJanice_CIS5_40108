/* 
  File:   main.cpp
  Author: Janice Ferrer
  Created on January 13, 2017, 7:31 PM
  Purpose:  Write a program to calculate the percentage of the federal budget 
 * that the Military and the NASA funded. 
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float military_budget, NASAbudget, US_total;
    float perc_milit, perc_NASA;
    //Input values
    US_total = 3.54E12;
    military_budget = 5.8E11;
    NASAbudget = 1.85E10;
    //Formula of conversion to find percentage of federal budget that NASA
    //and military funded
    perc_milit = (military_budget/US_total)*100;
    perc_NASA = (NASAbudget/US_total)*100;
    //Output values
    cout<<setprecision(2);
    cout<<"Percentage of federal budget that Military funded is: "
        <<perc_milit<<"%.\n";
    cout<<"Percentage of federal budget that NASA funded is: "
        <<perc_NASA<<"%.\n";
    //Exit stage right!
    return 0;
}