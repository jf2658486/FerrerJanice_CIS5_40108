/* 
  File:   main.cpp
  Author: Janice Ferrer
  Created on January 13, 2017, 7:54 PM
  Purpose:  Write a program to calculate the debt per person.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float pop_2008, pop_2016, debt_2008, debt_2016;
    float debtRate_08, debtRate_16;
    //Input values
    pop_2008 = 3.04E8;
    pop_2016 = 3.22E8;
    debt_2008 = 9.7E12;
    debt_2016 = 2.0E13;
    //Formula to calculate Debt per person
    debtRate_08 = debt_2008 / pop_2008;
    debtRate_16 = debt_2016 / pop_2016;
    //Output values
    cout<<"The Debt per person in 2008 was $"<<debtRate_08<<" per person.\n";
    cout<<"The Debt per person in 2016 was $"<<debtRate_16<<" per person.\n";
    //Exit stage right!
    return 0;
}