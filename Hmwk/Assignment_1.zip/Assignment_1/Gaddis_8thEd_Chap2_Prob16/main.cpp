/* 
  File:   main.cpp
  Author: Janice Ferrer
  Created on January 3, 2017, 12:15 PM
  Purpose:  Write a program that displays a diamond pattern.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    cout<<"   *   \n";
    cout<<"  ***  \n";
    cout<<" ***** \n";
    cout<<"*******\n";
    cout<<" ***** \n";
    cout<<"  ***  \n";
    cout<<"   *   \n";
    return 0;
}